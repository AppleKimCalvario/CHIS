// JavaScript for toggling the sidebar
let btn = document.querySelector('#btn');
let sidebar = document.querySelector('.sidebar');

btn.onclick = function () {
    sidebar.classList.toggle('active');
};

// JavaScript for showing/hiding the form
let addButton = document.querySelector('.action-button');
let residentForm = document.querySelector('#residentForm');

addButton.onclick = function () {
    residentForm.style.display = "block";
};
